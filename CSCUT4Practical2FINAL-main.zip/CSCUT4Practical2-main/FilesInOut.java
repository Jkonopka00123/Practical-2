import java.io.*;
import java.text.DateFormat;
import java.util.*;
import  java.text.SimpleDateFormat;
import java.io.FileWriter;
import java.io.IOException;


/**
 * 
 * CSCU9T4 Java strings and files exercise.
 *
 */
public class FilesInOut {



    public static void main(String[] args) throws IOException
    {
        /**
         * Add own directory here
         */
        //C:\Users\kubak\Documents\CSCUT4Practical2-main\inputm.txt
        FileReader reader = new FileReader("C:\\Users\\kubak\\Documents\\CSCUT4Practical2-main\\inputm.txt");


        //C:\Users\kubak\Documents\CSCUT4Practical2-main\output.txt
        /**
         * Add own directory here
         */
        PrintWriter writer = new PrintWriter("C:\\Users\\kubak\\Documents\\CSCUT4Practical2-main\\output.txt");


        // Set up a new Scanner to read the input file.
        char[] fullName;
        Scanner scan = new Scanner(reader);


        while (scan.hasNextLine())
        {
            fullName = scan.nextLine().toCharArray();
            fullName[0] = Character.toUpperCase(fullName[0]); //capitalises 1st letter in array
            char[] temp = new char[fullName.length + 2];
            //Stores the full name in a char Array 2 size larger to accommodate for date formatting
            for (int i = 0; i < fullName.length; i++)
            {
                temp[i] = fullName[i];
            }

            /**
             * This is to format the date into dd/mm/yyyy
             * The dateInt array is 1 size to big to avoid an index out of bounds error
             */
            char[] dateInt = new char[9];
            int counter = 8;
            for(int x = fullName.length - 1; x > fullName.length - 10; x--)
            {
                dateInt[counter] = fullName[x];
                counter--;
            }
            char[] dateFormatted = new char[11];
            counter = 0;
            for(int j = 0; j < dateFormatted.length; j++)
            {
                if (j == 3 || j == 6)  //"/" is added at index 3 and 6 instead of 2 and 5 due to earlier work around
                {
                    dateFormatted[j] = '/';
                }
                else {
                    dateFormatted[j] = dateInt[counter];
                    counter++;
                    //uses separate counter as the dateFormatted index would be out by 1 or 2 after indexes 3 and 6
                }
            }
            /**
             * loop goes through entire char array and and searches for empty spaces
             * if found capitalises char after the space
             */
            for (int i = 0; i<fullName.length; i++)
            {

                if(fullName[i] == ' ')
                {
                    //Checks if its an initial by checking index 2 places after
                    //if initial space will be empty
                    if(fullName[i+2] == ' ')
                    {
                        temp = new char[fullName.length + 1];
                        for (int x = 0; x < fullName.length; x++)
                        {
                            temp[x] = fullName[x];
                        }

                        /**
                         * moves array to right
                         */
                        for (int j = temp.length - 1; j > i + 2; j--)
                        {
                            temp[j] = temp[j - 1];
                        }
                        temp[i + 2]  = '.';

                    }
                    //capitalises char after empty space
                    temp[i + 1] = Character.toUpperCase(temp[i + 1]);
                }
                    //sets fullName to temp array
                    fullName = temp;


            }
            //Adds formatted date to end of fullName
            counter = 10;
            for (int i = fullName.length - 1; i > fullName.length - 11; i--)
            {
                fullName[i] = dateFormatted[counter];
                counter--;
            }

            //Outputs name to file
            System.out.println(fullName);
            writer.println(fullName);

        }
        writer.close();

        // Finally, add code to read the filenames as arguments from the command line.

    } // main

} // FilesInOut
